package qqq;
import java.util.Scanner;
public class ExtendedEuclideanAlgorithm {
	public static int modInverse(int a, int m)
	{
	    int []sol= ExtendedEuclid(a,m);
	    int g =sol[0];
	    if (g == 1) {
	         return (sol[2]%m + m) % m;
	    }
		return -1;
	}
	public static int[] ExtendedEuclid(int a, int b)
    { 
        int[] ans = new int[3];

        if (a == 0)  {
            ans[0] = b;
            ans[1] = 1;
            ans[2] = 0;
        }
        else
            {
               ans = ExtendedEuclid (b%a, a);
               int temp = ans[1] - ans[2]*(b/a);
               ans[1] = ans[2];
               ans[2] = temp;
            }

        return ans;
    }
	public static  void main(String[]args)
	{
	    while (true) {
		int a ,m;
	    @SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
	    System.out.println("Введите 2 числа для расчета инверсии" );
	    a=sc.nextInt();
	    m=sc.nextInt();
	    if (modInverse(a, m)==-1)
        System.out.println("Инверсии не существет");
	    else 
	    	System.out.println( "Инверсия равна: " + modInverse(a, m));
	    System.out.println();
	}
	}
}