package qqq;
import java.util.Scanner;
public class EuclideanAlgorithm {
    public static int getGreatestCommonDivisor(int number1, int number2) {
        while (number1 > 0 && number2 > 0) {
            if ((number2 % number1) == 0) {
                return number1;
            }
            number2 %= number1;
            if ((number1 % number2) == 0) {
                return number2;
            }
            number1 %= number2;
        }
        if (number1 == 0) {
            return number2;
        }
        return number1;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите числа для нахождения их наибольшего общего делителя (НОД)");
        System.out.println("Введите первое число: ");
        int number1 = scanner.nextInt();
        System.out.println("Введите второе число: ");
        int number2 = scanner.nextInt();
        if (number1 == 0 && number2 == 0) {
            System.out.println("Оба числа равны 0, найти НОД невозможно");
        } else
            System.out.println("НОД = " + getGreatestCommonDivisor(number1, number2));
    }
}