package qqq;

import java.util.Scanner;

public class MagicSquare {
    static int square[][] = {
            {1, 8, 11, 14},
            {12, 13, 2, 7},
            {6, 3, 16, 9},
            {15, 10, 5, 4}
    };
    static char cipher[][] = {
            {'a', 'a', 'a', 'a'},
            {'a', 'a', 'a', 'a'},
            {'a', 'a', 'a', 'a'},
            {'a', 'a', 'a', 'a'}
    };


    public static void main(String[] args) {

        System.out.println("Введите слово для шифрования:");
        Scanner scanner = new Scanner(System.in);
        String word = scanner.next();
        char msg[] = word.toCharArray();

        for (int i = 0; i <= msg.length - 1; i++)
            addChar(i + 1, msg[i]);

        StringBuilder builder = new StringBuilder();

        for (int q = 0; q < cipher.length - 1; q++)
            builder.append(cipher[q]);

        System.out.println("Зашифрованное сообщение: " + builder.toString());
    }

    static void addChar(int index, char ch) {

        mainLoop:
        for (int i = 0; i <= square.length - 1; i++) {
            for (int j = 0; j <= square[i].length - 1; j++) {
                if (square[i][j] == index) {
                    cipher[i][j] = ch;
                    break mainLoop;
                }
            }
        }
    }

}