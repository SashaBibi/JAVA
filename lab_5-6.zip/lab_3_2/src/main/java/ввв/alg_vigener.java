package ввв;

import java.util.*;

public class alg_vigener {
    static String []valores={" ","!","'","#","%","&","(",")","*","+",",","-",".","/","A","B","C","D","E","F","G","H","I","J","K","L","M","N","Ñ","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","ñ","o","p","q","r","s","t","u","v","w","x","y","z","{","}","á","é","í","ó","ú"};
    public static void main(String args[]){

        System.out.println("Шифр Виженера");
        Scanner scanner = new Scanner(System.in);
        int op=0;
        do {
            System.out.print("Функции: \n1.Кодирование\n2.Декодирование\n");
            op = Integer.parseInt(scanner.nextLine());
            switch(op){
                case 1:
                System.out.print("Введите текст для кодирования: ");
                String texto = scanner.nextLine();
                System.out.print("Введите ключевое слово: ");
                String key = (scanner.nextLine());
                String encVigener=encriptar(texto,key);
                System.out.println("Кодированный текст:"+encVigener);
                break;
                case 2:
                System.out.print("Введите текст для декодирования: ");
                String textod = scanner.nextLine();
                System.out.print("Введите ключевое слово: ");
                String keyd = (scanner.nextLine());
                String d=desencriptar(textod,keyd);
                System.out.println("Декодированный текст:"+d);
                break;
                default:
            }
        } while (op>=1&&op<=2);
    }

    private static String desencriptar(String texto,String key) {
        if(texto.length()<key.length()){
            key=key.substring(0, texto.length());
        }
        if(texto.length()>key.length()){
            String aux=key;
            while(texto.length()>key.length()){
                key+=aux;
            }
            key=key.substring(0, texto.length());

        }

        String d="";
        for(int el=0;el<key.length();el++){
            int idxT=buscarIndex(texto.charAt(el)+"");
            int idxK=buscarIndex(key.charAt(el)+"");
            int i=0;
            if(idxT-idxK<0){
                i=valores.length+(idxT-idxK);
            }
            else{
                i=(idxT-idxK)%valores.length;
            }
            d+=valores[i];
        }
        return d;
    }

    private static String encriptar(String texto, String key) {
        if(texto.length()<key.length()){
            key=key.substring(0, texto.length());

        }
        if(texto.length()>key.length()){
            String aux=key;
            while(texto.length()>key.length()){
                key+=aux;
            }
            key=key.substring(0, texto.length());

        }

        String cifrado="";
        for(int el=0;el<key.length();el++){
            int idxT=buscarIndex(texto.charAt(el)+"");
            int idxK=buscarIndex(key.charAt(el)+"");
            cifrado+=valores[(idxT+idxK)%valores.length];
        }
        return cifrado;
    }

    private static int buscarIndex(String el) {
        for(int i=0;i<valores.length;i++){
            if(el.equals(valores[i])){
                return i;
            }
        }
        return 0;
    }
}